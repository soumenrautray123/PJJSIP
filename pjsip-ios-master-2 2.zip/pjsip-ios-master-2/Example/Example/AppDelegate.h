//
//  AppDelegate.h
//  Example
//
//  Created by Pierre-Marc Airoldi on 2014-11-24.
//  Copyright (c) 2014 Pierre-Marc Airoldi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

