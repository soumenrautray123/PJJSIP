//
//  ViewController.m
//  Example
//
//  Created by Pierre-Marc Airoldi on 2014-11-24.
//  Copyright (c) 2014 Pierre-Marc Airoldi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
