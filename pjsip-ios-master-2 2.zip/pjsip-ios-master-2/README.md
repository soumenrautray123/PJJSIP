# pjsip-ios

[![Version](https://img.shields.io/cocoapods/v/pjsip-ios.svg?style=flat)](http://cocoadocs.org/docsets/pjsip-ios)
[![Platform](https://img.shields.io/cocoapods/p/pjsip-ios.svg?style=flat)](http://cocoadocs.org/docsets/pjsip-ios)

## Usage

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

pjsip-ios is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

    pod "pjsip-ios"

## Author

Pierre-Marc Airoldi, pierremarcairoldi@gmail.com

## License

pjsip-ios is available under the same license as pjsip. Go to their [licensing page](http://www.pjsip.org/licensing.htm) for more info.
